#ifndef MY_H_INCLUDED
#define MY_H_INCLUDED

extern int foo;
void print_foo();
void print(int);

void swap_v(int, int);
void swap_r(int&, int&);
void swap_cr(const int&, const int&);

#endif // MY_H_INCLUDED
