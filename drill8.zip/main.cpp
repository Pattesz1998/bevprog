# include "my.h"
# include <iostream>

int main()
{
foo = 7;
print_foo();

int x = 7;
int y = 9;

swap_v(x,y);


int x2 = 7;
int y2 = 9;

swap_r(x2,y2);

double x3 = 7;
double y3 = 9;

swap_cr(x3,y3);

return 0;
}
